function start(){
    paintCheckerBoard();
    goBackToOrigin();
}

function paintCheckerBoard(){
    for(var i = 0; i < 4; i++){
        paintRow();
        nextRowLeft();
        paintRow();
        nextRowRight();
    }
}

function paintRow(){
    while(frontIsClear()){
        paint(Color.black)
        move();
        paint(Color.red)
        if(frontIsClear()){
            move();
        }
    }
}

function nextRowLeft(){
    turnLeft();
    move();
    turnLeft();
}

function nextRowRight(){
    turnRight();
    if(frontIsClear()){
        move();
    }
    turnRight();
}

function goBackToOrigin(){
    turnRight();
    for(var i = 0;i < 7; i++){
        move();
    }
    turnLeft();
}
