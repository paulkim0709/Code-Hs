function start(){
	prepareTower();
	buildTower();
	jumpOff();
	prepareTower();
	buildTower();
	turnRight();
}
function prepareTower(){
    move();
    turnLeft();
}

function buildTower(){
    putBall();
    move();
    putBall();
    move();
    putBall();
    move();
}

function jumpOff(){
    turnLeft();
    turnLeft();
    move();
    move();
    move();
    turnLeft();
    move();
}

function turnRight(){
    turnLeft();
    turnLeft();
    turnLeft();
}

