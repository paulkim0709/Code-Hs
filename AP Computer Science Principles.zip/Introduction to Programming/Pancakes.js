move();
makePancakes();
move();
makePancakes();
move();
makePancakes();

function makePancakes() {
    putBall();
    putBall();
    putBall();
    move();
}

