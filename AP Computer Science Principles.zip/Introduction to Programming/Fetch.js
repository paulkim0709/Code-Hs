function start() {
    goToBall();
    pickBall();
    goBack();
}

//Brings Karel to Ball
function goToBall(){
    turnLeft();
    for (var i = 0; i < 4; i++){
        move();
    }
    turnRight();
    move();
    move();
}
//Picks up ball
function pickBall(){
    takeBall();
    turnAround();
}

//Goes back to origin
function goBack(){
    move();
    move();
    turnLeft();
    for (var i = 0; i < 4; i++){
        move();
    }
    putBall();
    turnLeft();
}
