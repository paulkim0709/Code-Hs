function start(){
	// This function will allow Karel to take the 100 balls and move forward
	pickUpBalls();
}

function pickUpBalls(){
    move();
    for(var i = 0; i < 100; i++){
	    takeBall();
	}
	move();
}
