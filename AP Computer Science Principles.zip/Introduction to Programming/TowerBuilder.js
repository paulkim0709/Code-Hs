//This is the start function
function start(){
    if(frontIsBlocked()){
        build();
        down();
    }
    while(frontIsClear()){
        build();
        down();
        if(frontIsClear()){
            move();
            if(frontIsClear()){
                move();
                if(frontIsBlocked()){
                    build();
                    down();
                }
            }
        }
    }
}



function build(){
    turnLeft();
    for (var i = 0; i < 3;i++){
        putBall();
        move();
    }
}

function down(){
    turnAround();
    for (var i = 0; i < 3;i++){
        move();
    }
    turnLeft();
}
