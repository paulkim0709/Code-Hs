function start(){
	buildSquare();
}

function buildSquare(){
    for(var i = 0; i < 4; ++i){
        putBall();
        move();
        turnLeft();
    }
}
