function start(){
    // Start here  
    moveToWall();
    placeBalls();
}

function moveToWall(){
    for(var i = 0; i < 5; i++){
        move();
    }
}

function placeBalls(){
    turnLeft();
    putBall();
    while(frontIsClear()){
        move();
        if(rightIsBlocked()){
            putBall();
        }
    }
    while(rightIsClear()){
        move();
    }
}

function putBalls(){
    putBall();
}
