putBall();
move();
function turnRight(){
    turnLeft();
    turnLeft();
    turnLeft();
}
turnRight();
move();
putBall();
move();
turnLeft();
move();
putBall();
