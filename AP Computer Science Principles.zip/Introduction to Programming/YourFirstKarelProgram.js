move();
move();
move();
move();
takeBall();
