function start(){
    changeColors();
}

function changeColors(){
    while(frontIsClear()){
        if(colorIs(Color.red)){
            paint(Color.blue)
            move();
        }else{
            paint(Color.red)
            move();
        }
        paintOppositeColor();
    }
}

function paintOppositeColor(){
    if(frontIsBlocked()){
        if(colorIs(Color.red)){
            paint(Color.blue)
        }else{
            paint(Color.red)
        }
    }
}

    







