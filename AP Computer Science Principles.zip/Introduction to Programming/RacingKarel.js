function start(){
    balls();
    goToCorner();
    goToSecond();
    goToThird();
    goToLast();
}

function balls(){
    for (var i = 0; i < 8; i++) {
        putBall(); 
    }
}
//Brings Karel to first corner
function goToCorner(){
    while (frontIsClear()){
        move();
    }
    if (frontIsBlocked()){
        for (var i = 0; i < 8; i++) {
            putBall();
        }
        turnLeft();
    }
}
//Brings Karel to the Second Corner
function goToSecond(){
    while (frontIsClear()){
        move();
    }
    if (frontIsBlocked()){
        for (var i = 0; i < 8; i++) {
            putBall();
        }
        turnLeft();
    }
}
//Brings Karel To the Third Corner
function goToThird(){
    while (frontIsClear()){
        move();
    }
    if (frontIsBlocked()){
        for (var i = 0; i < 8; i++) {
            putBall();
        }
        turnLeft();
    }
}

//This brings Karel back to home
function goToLast(){
    while (frontIsClear()){
        move();
    }
    if (frontIsBlocked()){
        turnLeft();
    }
}



