function start(){
    jumpHurdle();
}
function jumpHurdle(){
    turnLeft();
    move();
    turnRight();
    for(var i = 0; i < 13; i++){
        move();
    }
    turnRight();
    move();
    turnLeft();
}
