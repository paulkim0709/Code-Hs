function start() {
    move();
    makePancakes();
    moveForward();
    makePancakes();
    moveForward();
    makePancakes();
    move();
}

function makePancakes(){
    putBall();
    putBall();
    putBall();
}
function moveForward(){
    move();
    move();
}

