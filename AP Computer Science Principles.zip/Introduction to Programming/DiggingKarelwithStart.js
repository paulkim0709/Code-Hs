function start(){
    moveTwice();
    turnRight();
    buryBall();
    turnRight();
    threeMove();
    turnRight();
    buryBall();
    turnRight();
    threeMove();
    turnRight();
    buryBall();
    turnRight();
    move();
}
function turnRight(){
    turnLeft();
    turnLeft();
    turnLeft();
}
function turnAround(){
    turnLeft();
    turnLeft();
}
function moveTwice(){
    move();
    move();
}
function buryBall(){
    threeMove();
    putBall();
    turnAround();
    threeMove();
}
function threeMove(){
    move();
    move();
    move();
}
