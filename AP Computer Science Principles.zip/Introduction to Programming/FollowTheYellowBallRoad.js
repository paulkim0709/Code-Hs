function start() {
	followTheYellow();
}

function followTheYellow(){
    while (ballsPresent()){
        move();
    }
}
