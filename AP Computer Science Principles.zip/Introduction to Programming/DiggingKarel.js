move();
move();
getReady();
buryBall();
putBall();
lookUp();
buryBall();
getReady();
buryBall();
getReady();
buryBall();
putBall();
lookUp();
buryBall();
getReady();
buryBall();
getReady();
buryBall();
putBall();
lookUp();
buryBall();
getReady();
move();
function buryBall() {
    move();
    move();
    move();
}

 function lookUp() {
     turnLeft();
     turnLeft();
 }
 function getReady() {
     turnLeft();
     turnLeft();
     turnLeft();
 }
 
 

 
