/* This program draws a big tower from Karel's starting spot */
function start(){
	lookUp();
	buildTower();
}

function lookUp(){
    if (facingSouth()){
        turnAround();
    }
    if(facingWest()){
        turnRight();
    }
    if(facingEast()){
        turnLeft();
    }
}

function buildTower(){
    while (noBallsPresent()){
        putBall();
        if(frontIsClear()){
            move();
        }
    }
}
