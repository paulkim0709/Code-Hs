function start(){
    spin8Times();
}

function spin8Times(){
    for(var i = 0; i < 32; i ++){
        turnLeft();
    }
}
