function start(){
	// This functions allows karel to build two towers and end on the top of the second tower
	readyTower();
	buildTower();
	comeDown();
	nextTower();
	buildTower();
	finishedTower();
}
function readyTower(){
    //this function allows us to get rady to build the first tower
    move();
    turnLeft();
}
 
function buildTower(){
    putBall();
    move();
    putBall();
    move();
    putBall();
    move();
}

function comeDown(){
    turnAround();
    move();
    move();
    move();
    turnLeft();
}

function nextTower(){
    move();
    move();
    turnLeft();
}


function finishedTower(){
    turnRight();
}



