move();
turnAround();
move();
turnAround();
move();

function turnAround(){
	turnLeft();
	turnLeft();
}
