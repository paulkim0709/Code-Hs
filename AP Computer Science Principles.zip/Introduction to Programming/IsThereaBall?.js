function start() {
	avoidBall();

}

function avoidBall(){
    if(ballsPresent()){
        move();
    
    } else {
        putBall();
        move();
    }
}
