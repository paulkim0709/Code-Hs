function start(){
	whereDoYouGo();
}

function whereDoYouGo(){
    if(facingSouth()){
        turnLeft();
    }else{
        turnLeft();
        turnLeft();
    }
}
