function start(){
    move();
    buildTower();
    turnRight();
}
function turnRight(){
	turnLeft();
	turnLeft();
	turnLeft();
}














// function buildTower(){
//     putBall();
//     turnLeft();
//     move();
//     putBall();
//     move();
//     putBall();
//     move();
// }

function buildTower(){
    turnLeft();
    move();
    putBall();
    turnLeft();
    turnLeft();
    move();
    putBall();
    turnLeft();
    turnLeft();
    move();
    move();
    putBall();
    move();
}
