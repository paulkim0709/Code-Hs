moveHorse();
backflip();
moveHorse();
backflip();

function moveHorse() {
       move();
       move();
}

function backflip(){
    turnLeft();
    turnLeft();
    turnLeft();
    turnLeft();
}
