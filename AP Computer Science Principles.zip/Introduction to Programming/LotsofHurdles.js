function start(){
	runAndJump5Hurdles();
}

function runAndJump5Hurdles(){
    for(var i = 0; i < 5; i++) {
        move();
        move();
        jumpHurdle();
        turnRight();
        move();
        turnLeft();
    }
}

function jumpHurdle(){
    turnLeft();
    move();
    turnRight();
    move();
}
