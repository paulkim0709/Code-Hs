function start(){
    /*This is telling karel to move forward*/
	move();
	turnLeft();
	buildTower();
	move();
	turnRight();
	move();
	move();
	turnRight();
	move();
	buildTower();
	turnLeft();
	turnLeft();
	moveUp();
	turnRight();
}
function buildTower(){
    putBall();
    move();
    putBall();
    move();
    putBall();
}

function turnRight(){
    turnLeft();
    turnLeft();
    turnLeft();
}
function moveUp(){
    move();
    move();
    move();
}
