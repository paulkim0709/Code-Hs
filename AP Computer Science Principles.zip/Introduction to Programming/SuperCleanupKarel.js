//Start Function
function start() {
    rowOdd();
    rowEven();
}

function rowOdd(){
    while(frontIsClear()){
        move();
        if(ballsPresent()){
            takeBall();
        }
    }
    turnLeft();
    move();
    turnLeft();
}

function rowEven(){
    while(frontIsClear()){
        if(ballsPresent()){
            takeBall();
        }
        move();
    }
    turnRight();
    move();
    turnRight();
}
