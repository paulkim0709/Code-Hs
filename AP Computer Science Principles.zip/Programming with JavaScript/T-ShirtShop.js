//Declare a constant here to represent the cost of a tshirt

var COST_OF_SHIRT = 15;

function start(){
    var people = readInt("People? ");
	var totalPrice = people * COST_OF_SHIRT;
	println("Total price: " + totalPrice);
}
