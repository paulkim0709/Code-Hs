/* This program should draw the French flag. The
 * left third of the canvas is blue, the middle third
 * is white, and the right third is red. */
function start(){
	var blue = new Rectangle(getWidth() / 3, getHeight());
	blue.setPosition(0, 0);
	blue.setColor(Color.blue);
	add (blue);
	
	var white = new Rectangle(getWidth() / 3, getHeight());
	white.setPosition(getWidth() * (2/3), 0);
	white.setColor(Color.white);
	add (white);
	
	var red = new Rectangle(getWidth() / 3, getHeight());
	red.setPosition(getWidth() * (2/3), 0);
	red.setColor(Color.red);
	add(red);
}
