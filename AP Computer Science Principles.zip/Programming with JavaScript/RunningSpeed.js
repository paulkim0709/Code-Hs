/* Write a program that asks the user how far they ran (in miles)
 * and then how long it took them (in minutes), and print out
 * their speed in miles per hour. */
function start(){
	var distance = readInt("How far did you run? ");
	var time = readInt("How long did it take? ");
	
    var speed = 60 / time;
    var mph = speed * distance; 
    println(mph + "mps");
}
