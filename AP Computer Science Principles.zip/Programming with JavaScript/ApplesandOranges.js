function start(){
	    var numApples = 20;
	    println("Number of Apples: " + numApples);
	    
	    var numOranges = 15;
	    println("Number of Oranges: " + numOranges);
	    
	    numOranges = 15;
	    println("Number of Oranges: " + numOranges);
	    
	    numApples= 20;
	    println("Number or Apples: " + numApples);
}
