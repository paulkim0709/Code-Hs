function start(){
	var name = "Joe";
	println("My name is " + name);
	
	// Initializes numApples with value 5
	var numApples = 5;
	println("Number of apples: " + numApples);
	
	// Eat all apples
	numApples = 0;
	println("Number of apples: " + numApples);	
	
}
