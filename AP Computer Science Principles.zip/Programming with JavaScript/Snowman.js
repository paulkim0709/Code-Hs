/* Constants representing the radius of the top, middle,
 * and bottom snowball. */
var BOTTOM_RADIUS = 100;
var MID_RADIUS = 60;
var TOP_RADIUS = 30;

function start(){
	var small = new Circle (TOP_RADIUS);
	small.setPosition(getWidth() / 2, getHeight() / 4);
	small.setColor(Color.gray);
	add(small);
	
	var medium = new Circle (MID_RADIUS);
	medium.setPosition(getWidth() / 2, getHeight() / 2);
	medium.setColor(Color.gray);
	add(medium);
	
	var large = new Circle (BOTTOM_RADIUS);
	large.setPosition(getWidth() / 2, getHeight() / 1 - BOTTOM_RADIUS);
	large.setColor(Color.gray);
	add(large);
}
