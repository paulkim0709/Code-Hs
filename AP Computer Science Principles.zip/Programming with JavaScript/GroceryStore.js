function start(){
    var name = readLine("Name ");
	var numApples = readInt("Apples ");
	var numOranges = readInt("Oranges ");
	println("Hi " + name + ", you want " + numApples + " apples and " + numOranges + " oranges");
}
