
// DESCRIBE YOUR FILTER HERE IN THIS COMMENT!
function customFilter(image) {
    
    for(var x = 0; x < image.getWidth(); x++) {
        for (var y = 0; y < image.getHeight(); y++) {
            // Get the current pixel
            var pixel = image.getPixel(x, y);
            
            // Update pixel with DARK_LEVEL (based on other color's value)
            pixel = updatePixelwithDarkLevel(pixel);
            
            // Set swap colors (RED<--GREEN, GREEN<--BLUE, BLUE<--RED) 
            pixel = swapPixel(pixel);
            
            // Remove pixel Color with parameter (RED / GREEN/ BLUE)
            pixel = removePixelColor (pixel, RED);
            
            // Update the image with the modified pixel
            image.setRed(x, y, pixel[RED]);
            image.setGreen(x, y, pixel[GREEN]);
            image.setBlue(x, y, pixel[BLUE]);
        }
    }
}

// WRITE ANY HELPER FUNCTIONS HERE
function swapPixel(pixel) {
     // WRITE THIS FUNCTION

    // Set swap colors (RED<--GREEN, GREEN<--BLUE, BLUE<--RED) 
    var Temp = pixel[RED];
    pixel[RED] = pixel[GREEN];
    pixel[GREEN] =  pixel[BLUE];
    pixel[BLUE] = Temp;
    
    // Return the modified pixel array
    return pixel;
}

// WRITE ANY HELPER FUNCTIONS HERE
function updatePixelwithDarkLevel(pixel) {
    var red = pixel[RED];
    var green = pixel[GREEN];
    var blue = pixel[BLUE];

    var newRed = red;
    var newGreen = green;
    var newBlue = blue;
    
     // Update dark level based on other color's value.
    if (red >= green)
    {
       newRed = red - DARK_LEVEL;
    }
    else if (green >= blue) 
    {
       newGreen = green - DARK_LEVEL;
    }
    else if (blue >= red) 
    {
       newBlue =  blue - DARK_LEVEL;
    }
    
    // If the value is below 0, set it to 0
    newRed = Math.max(newRed, MIN_PIXEL_VALUE);
    newGreen = Math.max(newGreen, MIN_PIXEL_VALUE);
    newBlue = Math.max(newBlue, MIN_PIXEL_VALUE);
    
    pixel[RED] = newRed;
    pixel[GREEN] = newGreen;
    pixel[BLUE] = newBlue;
   
    // Return the modified pixel array
    return pixel;
}

function removePixelColor(pixel, color) {
    var red = pixel[RED];
    var green = pixel[GREEN];
    var blue = pixel[BLUE];
    
    var newRed = red;
    var newGreen = green;
    var newBlue = blue;
   
    // Update the pixel with the modified pixel
    if (color == RED)
    {
        newRed = 0;
    }
    else if (color == GREEN) 
    {
        newGreen = 0;
    }
    else if (color == BLUE) 
    {
       newBlue = 0;
    }
   
    pixel[RED] = newRed;
    pixel[GREEN] = newGreen;
    pixel[BLUE] = newBlue;
    
    // Return the modified pixel array
    return pixel;
}


/*********************************************
 * You do not need to write any code below this line.
 * This is starter code that sets up the image on the screen
 * and calls your customFilter function.
 * Feel free to read this code and learn how it works!
 * Be careful though, if you modify this code the program may not
 * work correctly.
 *********************************************/
 
// Constants for the image
var IMAGE_URL = "https://codehs.com/static/img/zebra.jpg";
var IMAGE_WIDTH = 350;
var IMAGE_HEIGHT = 250;
var IMAGE_X = getWidth() / 2 - IMAGE_WIDTH / 2;
var IMAGE_Y = getHeight() / 2 - IMAGE_HEIGHT / 2;

// Constants for the pixel array
var RED = 0;
var GREEN = 1;
var BLUE = 2;

// Constants for the pixel filter
var MAX_COLOR_VALUE = 255;

// Constants for the filter
var DARK_LEVEL = 30;
var MIN_PIXEL_VALUE = 0;

// We need to wait for the image to load before modifying it
var IMAGE_LOAD_WAIT_TIME = 50; 

function start() {
    // Set up the image
    var image = new WebImage(IMAGE_URL);
    image.setSize(IMAGE_WIDTH, IMAGE_HEIGHT);
    image.setPosition(IMAGE_X, IMAGE_Y);
    
    // Add it to the canvas
    add(image);
    
    // Wait for it to load before applying the filter
    setTimeout(function(){
        customFilter(image);
   
    }, IMAGE_LOAD_WAIT_TIME);
}
