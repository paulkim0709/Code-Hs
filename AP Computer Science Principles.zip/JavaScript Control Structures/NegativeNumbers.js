// This program reads a number from the
// user and prints if it is negative.
function start(){
	var number = readInt("Number: ");
	if(number < 0){
		println("Number is negative.");
	}
}
