var N = 5;

function start(){
	for(var i = N; i > 0; i++){
	    println(i)
	}
}
