function start() {
	keyDown();
	keyUp();
	
	var rect = new rectangle(200,50);
	rect.setPosition(0, 0);
	rect.setColor(Color.pink);
	add(rect);
}

function keyDown(e) {
	if (e.keyCode == Keyboard.LEFT) {
		ball.move(-5, 0);
	}
	if(e.keyCode == Keyboard.letter('K')){
		println("You pressed K");
	}
}
