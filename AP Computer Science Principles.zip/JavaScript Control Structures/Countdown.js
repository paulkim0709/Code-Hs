// This program prints a countdown from
// ten down to zero using a for loop.
function start(){
	for(var i = 10; i >= 0; i--){
		println(i);
	}
}
