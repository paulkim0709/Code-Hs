function start(){
    var weekday = readBoolean("Is today a weekday? ");
    var holiday = readBoolean("Is today a holiday? ");
    var noSchoolToday = holiday || !weekday;
    println("There is no school today: " + noSchoolToday);
}
