function start(){
	var light = readLine("Color? ");
	if (light == "red"){
	    println("Red light: you should stop.");
	    
	} else if (light == "Yellow"){
	    println(light + ": Be careful now!");
	    
	} else {
	    println(light +  ": Go!");
	}
}
