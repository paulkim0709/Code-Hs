function start(){
	for(var i = 0; i < 100; i++){
	    println("I will not come late to school");
	}
}
