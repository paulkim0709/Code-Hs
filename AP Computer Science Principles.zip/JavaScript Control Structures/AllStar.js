var points = readInt("Points? ");
var rebounds = readInt("Rebounds? ");
var assists = readInt("Assists? ");
if (points >= 25 || points >= 10 && rebounds >= 10 && assists >= 10){
    println("true");
}else{
    println("false");
}
