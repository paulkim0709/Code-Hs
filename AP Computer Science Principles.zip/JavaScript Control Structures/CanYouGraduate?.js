function start(){
	var hasEnoughCredits = readBoolean("Do you have enough credits? ");
	var metRequirements = readBoolean("Do you meet the requirements? ");
	var canGraduate = hasEnoughCredits && metRequirements;
	println("Can you Graduate? " + canGraduate);
}
