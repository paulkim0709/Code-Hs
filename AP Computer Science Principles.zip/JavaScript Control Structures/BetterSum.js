var FIRST = readLine("First Number:");
var SECOND = readLine("Second Number:");

function start(){
	var sum = 0;
	for(var i = FIRST; i <= SECOND; i++){
	    sum += i;
	}
	var Tiny = sum
	println("The was is " + Tiny);

}
