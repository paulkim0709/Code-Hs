var NUM_CIRCLES = 15;

// This graphics program should draw a caterpillar. A caterpillar has NUM_CIRCLES
// circles. Every other circle is a different color, the even circles are red, and
// the odd circles are green. Use a for loop to draw the caterpillar, centered 
// vertically in the screen.
function start(){
	for(var i = 0; i < 15;i++){
	    var worm = new Circle(NUM_CIRCLES);
	    worm.setPosition(15 + 30 * i, getHeight() / 2);
	    if(i % 2){
	        worm.setColor(Color.green)
	    }else{
	        worm.setColor(Color.red);
	    }
	    add(worm)
	}
}
