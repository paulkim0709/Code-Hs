function start(){
	for(var i = 0; i < 3; i++){
		println(i);
	}
}
