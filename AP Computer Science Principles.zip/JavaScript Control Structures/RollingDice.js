function start(){
	var firstRoll = readInt("What did you get on your first roll? ");
	var secondRoll = readInt("What did you get on your second roll? ");
	var rolledDoubles = firstRoll == secondRoll;
	if (rolledDoubles){
	    println("true");
	}else{
	    println("false");
	}
}
