// In this program we declare a boolean
// value to represent whether the user
// is logged in, and then print it out.
function start(){
	var loggedIn = false;
	println("User logged in?: " + loggedIn);
}
